<?
session_start();
if (!session_is_registered("codigo_adm"))
{  header("Location: index.php");}
else
{
   $cd_admin = $HTTP_SESSION_VARS['codigo_adm'];
   $sn_admin = $HTTP_SESSION_VARS['senha_adm'];
   $Query_admin=mysql_query("select * from tb_usuario where cd_usuario='$cd_admin' and ds_senha='$sn_admin'") or die("erro query selecao usuario");
   $linha=mysql_num_rows($Query_admin);
   if ($linha==0)
   {  header("Location: index.php");}
}
?>
