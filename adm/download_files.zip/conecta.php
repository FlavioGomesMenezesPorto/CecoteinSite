<?
$dbhost = 'localhost';
$dbuser = 'root';
$dbpasswd = '';
$database = 'cecotein';
if ($_SERVER['HTTP_HOST'] != 'localhost') 
{
   $dbhost = 'mysql01.cecotein.com.br';
   $dbuser = 'cecotein';
   $dbpasswd = 'cecote1212';
   $database = 'cecotein';
}
mysql_connect($dbhost,$dbuser,$dbpasswd);
mysql_select_db($database);
?>
